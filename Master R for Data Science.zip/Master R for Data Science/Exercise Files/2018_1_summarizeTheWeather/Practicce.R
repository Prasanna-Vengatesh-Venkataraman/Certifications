install.packages("lubridate")
library(lubridate)

a1 <- read.delim(file.choose(), header = T)
a2 <- read.delim(file.choose(), header = T)
a3 <- read.delim(file.choose(), header = T)
a4 <- read.delim(file.choose(), header = T)

Data <- as.data.frame(rbind(a1,a2,a3,a4))

Data2 <- Data[,c("Barometric_Press","date.......time")]
Data2$date.......time <- ydm_hms(Data2$date.......time)

slope <- function(sd,ed){
  Data3 <- Data2[Data2$date.......time >= ydm_hms(sd) & Data2$date.......time <= ydm_hms(ed),]
  lmmodel <- lm(Data3$Barometric_Press~Data3$date.......time)
  plot(Data3$date.......time, Data3$Barometric_Press, xlab="Date & Time", ylab = "Barometric Pressure", col="blue", pch=19)
  abline(lmmodel, col="red", lwd=3)
  print(lmmodel$coefficients)
}

slope("2014-02-01 12:03:34","2014-04-01 12:03:34")
slope("2012-01-01 00:02:14","2012-01-01 23:58:15")
slope("2012-01-10 00:00:00","2012-01-12 23:59:59")
slope("2012-01-10 00:00:00","2014-01-12 23:59:59")
